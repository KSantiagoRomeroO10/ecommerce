package com.example.backend.Repository.Adapters;

import com.example.backend.Models.Productos;
import com.example.backend.Ports.Out.ProductosOut;
import com.example.backend.Repository.Entities.ProductosEntity;
import com.example.backend.Repository.JpaRepository.ProductosJpaRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class ProductosAdapter implements ProductosOut {

    @Autowired
    private ProductosJpaRepository productosJpaRepository;

    // Convertir de dominio a entidad JPA
    private ProductosEntity toEntity(Productos producto) {
        return new ProductosEntity(
                producto.getIdProducto(),
                producto.getNombreProducto(),
                producto.getPrecioProducto(),
                producto.getDescripcionProducto(),
                producto.getStockProducto(),
                null // No cargamos ventaProductos aquí por simplicidad
        );
    }

    // Convertir de entidad JPA a dominio
    private Productos toModel(ProductosEntity entity) {
        return new Productos(
                entity.getIdProducto(),
                entity.getNombreProducto(),
                entity.getPrecioProducto(),
                entity.getDescripcionProducto(),
                entity.getStockProducto()
        );
    }

    @Override
    public Productos guardarProducto(Productos producto) {
        ProductosEntity entity = toEntity(producto);
        return toModel(productosJpaRepository.save(entity));
    }

    @Override
    public Optional<Productos> buscarProductoPorId(Long id) {
        return productosJpaRepository.findById(id)
                .map(this::toModel);
    }

    @Override
    public List<Productos> listarProductos() {
        return productosJpaRepository.findAll()
                .stream()
                .map(this::toModel)
                .collect(Collectors.toList());
    }

    @Override
    public Productos actualizarProducto(Productos producto) {
        ProductosEntity entity = toEntity(producto);
        return toModel(productosJpaRepository.save(entity));
    }

    @Override
    public Long eliminarProducto(Long id) {
        productosJpaRepository.deleteById(id);
        return id;
    }
}
