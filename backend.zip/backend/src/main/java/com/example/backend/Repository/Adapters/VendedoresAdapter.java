package com.example.backend.Repository.Adapters;

public class VendedoresAdapter{

}
